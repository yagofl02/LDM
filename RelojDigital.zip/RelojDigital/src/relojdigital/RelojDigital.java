/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package relojdigital;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JLabel;

/**
 *
 * @author danie
 */
public class RelojDigital extends JLabel implements Serializable {
    
    private boolean segundos;
    private Alarma alarma;
    
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
    private final SimpleDateFormat sdfSegundos = new SimpleDateFormat("HH:mm:ss");
    
    private AlarmaListener alarmaListener;
    
    public RelojDigital () {
        Timer timer = new Timer();
        timer.schedule(new TimerTask(){
            @Override
            public void run (){
                Date horaActual = new Date();
                if (segundos) {
                    setText(sdfSegundos.format(horaActual));
                } else {
                    setText(sdf.format(horaActual));
                }
                
                if (alarma != null) {
                    if (alarma.isActiva() && horasCoinciden(horaActual, alarma.getHoraAlarma())) {
                        if (alarmaListener != null) {
                            alarmaListener.suenaAlarma();
                        }
                    }
                }
            }
        },0, 1000);
    }
    
    public void addAlarmaListener (AlarmaListener alarmaListener) {
        this.alarmaListener = alarmaListener;
    }
    
    private boolean horasCoinciden(Date horaActual, Date horaAlarma) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(horaActual);
        int horasActual, minActual, segActual, horasAlarma, minAlarma, segAlarma;
        horasActual = calendar.get(Calendar.HOUR_OF_DAY);
        minActual = calendar.get(Calendar.MINUTE);
        segActual = calendar.get(Calendar.SECOND);

        calendar.setTime(horaAlarma);
        horasAlarma = calendar.get(Calendar.HOUR_OF_DAY);
        minAlarma = calendar.get(Calendar.MINUTE);
        segAlarma = calendar.get(Calendar.SECOND);

        if (horasActual == horasAlarma && minActual == minAlarma && segActual == segAlarma)
            return true;
        else
            return false;
    }
}
